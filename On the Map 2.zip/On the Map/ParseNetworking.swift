//
//  Networking.swift
//  On the Map
//
//  Created by Majed Sh on 2/9/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation

class ParseNetworking {
    
    static let shared = ParseNetworking()
    
    var session = URLSession.shared
    var objectId : String? = nil
    
    func request(url: String, method: String, parameters: Data? = nil, completion: @escaping (_ status: Bool, _ data: Data?) -> Void) {
        
        var request = URLRequest(url: URL(string: url)!)
        
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
        
        request.httpBody = parameters
        request.httpMethod = method
        
        URLSession.shared.dataTask(with: request) { (data, response1, error) in
            guard let response = response1 as? HTTPURLResponse,
                let data = data, (response.statusCode >= 200 && response.statusCode < 300) else {
                    completion(false, nil)
                    return
            }
            completion(true, data)
            }.resume()
    } 
        func postLocation(location: ParseNetworking.StudentLocation, completion: @escaping (_ status: Bool) -> Void) {
        let url = "https://parse.udacity.com/parse/classes/StudentLocation"
        var params: Data?
        do {
            params = try JSONEncoder().encode(location)
        } catch {
            print(error)
        }
        request(url: url, method: "POST", parameters: params) { (status, data) in
            guard status else {
                completion(false)
                return
            }
            do {
                let data = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(data)
                completion(true)
            } catch {
                print(error)
                completion(false)
            }
        }
    }
    
    func getLocations(limit: Int = 100, skip: Int = 0, orderBy: String = "updatedAt", completion: @escaping ([StudentLocation]?) -> Void) {
        let url = "https://parse.udacity.com/parse/classes/StudentLocation?limit=\(limit)&skip=\(skip)&order=-\(orderBy)"
        
        request(url: url, method: "GET") { (status, data) in
            guard status else {
                completion(nil)
                return
            }
            do {
                let location = try JSONDecoder().decode(StudentLocationResult.self, from: data!)
                completion(location.results)
            } catch {
                completion(nil)
            }
        }
    }
    

    struct StudentLocationResult: Codable {
        var results: [StudentLocation]?
    }
    
    struct StudentLocation: Codable {
        var createdAt: String?
        var firstName: String?
        var lastName: String?
        var latitude: Double?
        var longitude: Double?
        var mapString: String?
        var mediaURL: String?
        var objectId: String?
        var uniqueKey: String?
        var updatedAt: String?
    }
    
    class func sharedInstance() -> ParseNetworking {
        struct Singleton {
            static var sharedInstance = ParseNetworking()
        }
        return Singleton.sharedInstance
    }
    
}

