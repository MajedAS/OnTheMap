//
//  StudentLocation.swift
//  On the Map
//
//  Created by Majed Sh on 2/20/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation
