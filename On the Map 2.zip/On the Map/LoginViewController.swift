//
//  LoginViewController.swift
//  On the Map
//
//  Created by Majed Sh on 2/7/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import UIKit
import SafariServices

class LoginViewController: UIViewController {

    
    @IBOutlet weak var emailTextfield: UITextField!
    
    
    @IBOutlet weak var passwordTetfield: UITextField!
    
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBAction func loginTapped(_ sender: Any) {
        if ReachabilityTest.isConnectedToNetwork() {
        var loggedIn: Bool = false
        if emailTextfield.text == "" || passwordTetfield.text == ""  {
            Alert.showBasicAlert(on: self, with: "Username or Password cannot be empty !")
        } else {
            UdacityAccountController.shared.login(username: emailTextfield.text!, password: passwordTetfield.text!) { (error) in
                DispatchQueue.main.async {
                if error != nil {
                    loggedIn = false
                    Alert.showBasicAlert(on: self, with: "Username or Password are incorrect!")
                } else {
                    loggedIn = true
                    self.completeLogin()
                    }
                }
            }
            }
        if loggedIn {
            self.completeLogin()
        }
        
        } else {
            Alert.showBasicAlert(on: self, with: "Please check your network and try again.")
        }
    }
    
    @IBAction func signupTapped(_ sender: Any) {
        let url = URL(string: "https://www.udacity.com/account/auth#!/signup")
        guard let newUrl = url else {return}
        let svc = SFSafariViewController(url: newUrl)
        present(svc, animated: true, completion: nil)
    }
        
    override func viewWillDisappear(_ animated: Bool) {
        emailTextfield.text = ""
        passwordTetfield.text = ""
        
    }
    
    private func completeLogin() {
        let controller = storyboard!.instantiateViewController(withIdentifier: "ManagerTabBarController") as! UITabBarController
        present(controller, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
