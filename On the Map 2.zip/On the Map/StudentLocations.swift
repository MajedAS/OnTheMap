//
//  StudentLocations.swift
//  On the Map
//
//  Created by Majed Sh on 2/7/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation


struct StudentLocations : Codable {
    let results : [Results]?
}

struct Results : Codable {
    let createdAt:String?
    let firstName:String?
    let lastName:String?
    let latitude:Double?
    let longitude:Double?
    let mapString:String?
    let mediaURL:String?
    let uniqueKey:String?
    let updatedAt:String?
    let objectId:String?
}

struct StudentLocationsBody : Codable {
    let uniqueKey:String?
    let firstName:String?
    let lastName:String?
    let mapString:String?
    let mediaURL:String?
    let latitude:Double?
    let longitude:Double?
}

struct StudentLocation: Codable {
    var createdAt: String?
    var firstName: String?
    var lastName: String?
    var latitude: Double?
    var longitude: Double?
    var mapString: String?
    var mediaURL: String?
    var objectId: String?
    var uniqueKey: String?
    var updatedAt: String?
}

struct StudentLocationsResponse : Codable {
    let createdAt : String?
    let objectId : String?
}

struct StudentLocationsUpdateResponse : Codable {
    let createdAt : String?
}
