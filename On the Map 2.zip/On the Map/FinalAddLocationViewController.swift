//
//  FinalAddLocationViewController.swift
//  On the Map
//
//  Created by Majed Sh on 2/18/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation
import MapKit

class FinalAddLocationViewController: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!

    var mapString:String?
    var mediaURL:String?
    var latitude:Double?
    var longitude:Double?
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = true
        
        createAnnotation()
        
    }
    
    
    
    @IBAction func finishTapped(_ sender: UIButton) {
            postNewStudentLocation()
    }
    
    func postNewStudentLocation(){

        if let nickname = UdacityAccountController.sharedInstance().nickname {
            var components = nickname.components(separatedBy: " ")
            if(components.count > 0)
            {
                let firstName = components.removeFirst()
                let lastName = components.joined(separator: " ")
            
                var x = ParseNetworking.StudentLocation()
                x.firstName = firstName
                x.lastName = lastName
                x.latitude = latitude
                x.longitude = longitude
                x.mapString = mapString
                x.mediaURL = mediaURL
                x.uniqueKey = UdacityAccountController.sharedInstance().id
                


                
                ParseNetworking.sharedInstance().postLocation(location: x) { (status) in
                    if status {
                        print(status)
                        self.returnBackToRoot()

                    } else {
                        Alert.showBasicAlert(on: self, with: "Posting location Failed")
                        
                        }
                }
                
            }
            
        }
        }
    
    func returnBackToRoot() {
        DispatchQueue.main.async {
            self.tabBarController?.tabBar.isHidden = false
            if let navigationController = self.navigationController {
                navigationController.popToRootViewController(animated: true)
            }
        }
        
    }
    
    func createAnnotation(){
        let annotation = MKPointAnnotation()
        annotation.title = mapString!
        annotation.subtitle = mediaURL!
        annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
        self.mapView.addAnnotation(annotation)
        
        
        let coredinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coredinate, span: span)
        self.mapView.setRegion(region, animated: true)
        
    }
    
    
}
