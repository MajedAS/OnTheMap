//
//  UsersDataTableViewController.swift
//  On the Map
//
//  Created by Majed Sh on 2/14/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation
import SafariServices
import UIKit

class UsersDataTableViewController: UIViewController {
    
    @IBOutlet weak var usersDataTableview: UITableView!
    
    var usersDataArray = ModelDataArray.shared.usersDataArray
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        getAllUsersData()
    }
    
    
    func getAllUsersData(){
        usersDataArray.removeAll()
        
        ActivityIndicator.startActivityIndicator(view: self.view)
        
        ParseNetworking.sharedInstance().getLocations { (locations) in
            guard let newUsersData = locations else {return}
            self.usersDataArray = newUsersData
            
            DispatchQueue.main.async {
                ActivityIndicator.stopActivityIndicator()
                self.usersDataTableview.reloadData()
        }
            
    }
    }
    
    @IBAction func refreshTapped(_ sender: Any) {
        getAllUsersData()
    }
    

    @IBAction func logoutTapped(_ sender: Any) {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { print(error)
                return
            }
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range) /* subset response data! */
            print(String(data: newData!, encoding: .utf8)!)
        }
        self.dismiss(animated: true, completion: nil)
        task.resume()
    }
    
    @IBAction func addLocationTapped(_ sender: Any) {
        DispatchQueue.main.async {
                self.performSegue(withIdentifier: "toAddLocation", sender: nil)
        }
    }
    
    
}


extension UsersDataTableViewController:UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return usersDataArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UsersDataCell") as! UsersDataTableViewCell
        
        
        cell.fillCell(usersData: usersDataArray[indexPath.row] as! ParseNetworking.StudentLocation)
        
        return cell
        
    }
    
    
}



extension UsersDataTableViewController:UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dataArray = usersDataArray as! [ParseNetworking.StudentLocation]
        
        if let urlString = dataArray[indexPath.row].mediaURL,
            let url = URL(string: urlString){
            
            if url.absoluteString.contains("http://"){
                let svc = SFSafariViewController(url: url)
                present(svc, animated: true, completion: nil)
            }else {
                
                DispatchQueue.main.async {
                    Alert.showBasicAlert(on: self, with: "Cannot Open , Because it's Not Vailed Website !!")
                }            }
            
        }
    }
}
