//
//  ModelDataArray.swift
//  On the Map
//
//  Created by Majed Sh on 2/8/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation

class ModelDataArray {
    static let shared = ModelDataArray()
    
    var usersDataArray = [Any?]()
    
    private init() { }
}
