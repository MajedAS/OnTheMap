//
//  MapViewController.swift
//  On the Map
//
//  Created by Majed Sh on 2/8/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import UIKit
import MapKit
import SafariServices

class MapViewController: UIViewController {

    
    @IBOutlet weak var mapView: MKMapView!
    
    var usersDataArray = ModelDataArray.shared.usersDataArray
    
    private var annotations = [MKPointAnnotation]()
    
    var studentInformation: Results?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        }
    
    func getAllUsersData(){

        self.usersDataArray.removeAll()
        annotations.removeAll()
        let allAnnotations = self.mapView.annotations
        self.mapView.removeAnnotations(allAnnotations)

        ActivityIndicator.startActivityIndicator(view: self.view)



        ParseNetworking.sharedInstance().getLocations { (locations) in
            
            self.usersDataArray = locations!
            self.organizingUsersData(userDataArray: self.usersDataArray as! [ParseNetworking.StudentLocation])
            self.stopActivityIdecator()
        }
    }
    
    func organizingUsersData(userDataArray:[ParseNetworking.StudentLocation]){
        for i in userDataArray {
            if let latitude = i.latitude , let longitude = i.longitude , let first = i.firstName ,let last = i.lastName , let mediaURL = i.mediaURL {
                
                let lat = CLLocationDegrees(latitude)
                let long = CLLocationDegrees(longitude)
                
                let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
                
                let annotation = MKPointAnnotation()
                annotation.coordinate = coordinate
                annotation.title = "\(first) \(last)"
                annotation.subtitle = mediaURL
                
                self.annotations.append(annotation)
            }
            DispatchQueue.main.async {
                self.mapView.addAnnotations(self.annotations)
                ActivityIndicator.stopActivityIndicator()
                
                
            }
            
            
        }
        
    }
    
    func stopActivityIdecator(){
        DispatchQueue.main.async {
            ActivityIndicator.stopActivityIndicator()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAllUsersData()
        }
    
    @IBAction func logoutTapped(_ sender: Any) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { print(error)
                return
            }
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range) /* subset response data! */
            print(String(data: newData!, encoding: .utf8)!)
        }
        self.dismiss(animated: true, completion: nil)
        task.resume()
    }
    
    @IBAction func refreshTapped(_ sender: Any) {
        getAllUsersData()
    }
    
    @IBAction func addUserLocationTapped(_ sender: Any) {
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: "toAddLocation", sender: nil)
        }

        
    }
    
}

extension MapViewController:MKMapViewDelegate{
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .infoDark)
        }
        else {
            pinView!.annotation = annotation
        }
        
        
        return pinView
    }
    
    
    
    func openUrlInSafari(url:URL){
        
        if url.absoluteString.contains("http://"){
            let svc = SFSafariViewController(url: url)
            present(svc, animated: true, completion: nil)
        }else {
            DispatchQueue.main.async {
                Alert.showBasicAlert(on: self, with: "Cannot Open , Because it's Not Vailed Website !!")
            }
        }
        
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            
            if let toOpen = view.annotation?.subtitle! {
                guard let url = URL(string: toOpen) else {return}
                openUrlInSafari(url:url)
                
            }
        }
    }
    
    func mapView(mapView: MKMapView, annotationView: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        if control == annotationView.rightCalloutAccessoryView {
            guard let newUrl = annotationView.annotation?.subtitle else {return}
            guard let stringUrl = newUrl else {return}
            guard let url = URL(string: stringUrl) else {return}
            openUrlInSafari(url:url)
            
        }
    }
}


