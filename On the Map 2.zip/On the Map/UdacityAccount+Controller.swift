//
//  UdacityAccountController.swift
//  On the Map
//
//  Created by Majed Sh on 2/9/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import UIKit

struct StudentLocation1: Codable {
    var createdAt: String?
    var firstName: String?
    var lastName: String?
    var latitude: Double?
    var longitude: Double?
    var mapString: String?
    var mediaURL: String?
    var objectId: String?
    var uniqueKey: String?
    var updatedAt: String?
}

    struct UdacitySessionBody : Codable {
        let udacity : Udacity
    }
    
    struct Udacity : Codable {
        let username:String
        let password:String
    }
    
    struct UdacitySessionResponse : Codable {
        let account : Account
        let session : Session
    }
    
    struct Account : Codable {
        let registered : Bool?
        let key : String?
    }
    
    struct Session : Codable {
        let id : String?
        let expiration : String?
    }

    struct UdacityUserData : Codable {
    let nickname : String?
    
}


class UdacityAccountController {
    
    static let shared = UdacityAccountController()
    
    var key: String? = ""
    var id: String? = ""
    var nickname: String? = "Conrad Hamill"
    
    
    func request(url: String, method: String, parameters: Data? = nil, completion: @escaping (_ status: Bool, _ data: Data?) -> Void) {
        
        var request = URLRequest(url: URL(string: url)!)
        
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
        
        request.httpBody = parameters
        request.httpMethod = method
        
        URLSession.shared.dataTask(with: request) { (data, response1, error) in
            guard let response = response1 as? HTTPURLResponse,
                let data = data, (response.statusCode >= 200 && response.statusCode < 300) else {
                    completion(false, nil)
                    return
            }
            completion(true, data)
            }.resume()
    }
    
    func login(username: String, password: String, completion: @escaping (_ error: String?) -> Void){
        let params = "{\"udacity\": {\"username\": \"\(username)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        let url = "https://onthemap-api.udacity.com/v1/session"
        request(url: url, method: "POST", parameters: params) { (status, data) in
            guard status else {
                completion("incorrect username or password")
                return
            }
            do {
                let newData = data?.subdata(in: 5..<data!.count)
                let data = try JSONSerialization.jsonObject(with: newData!, options: .allowFragments)  as? [String: Any]
                let sessionDict = data?["session"] as? [String: Any]
                let accountDict = data?["account"] as? [String: Any]
                self.key = accountDict?["key"] as? String ?? ""
                print(self.key)
                self.id = sessionDict?["id"] as? String ?? ""
                completion(nil)
            } catch {
                completion("couldn't serialize the object")
            }
        }
    }
    
    func getUserInfo(completion: @escaping (_ status: Bool) -> Void) {
        let url = "https://onthemap-api.udacity.com/v1/users/\(self.key)"
        request(url: url, method: "GET") { (status, data) in
            guard status else {
                return
            }
            let newData = data?.subdata(in: 5..<data!.count)
            do {
                let object = try JSONSerialization.jsonObject(with: newData!, options: [])
                print(object)
//                let nicknameResult = try JSONDecoder().decode(UdacityUserData.self, from: newData!)
//                let newResult = nicknameResult as! UdacityUserData
//                self.nickname = newResult.nickname
                completion(true)
            } catch {
                completion(false)
            }
        }
    }
    
    /*
 let url = "https://onthemap-api.udacity.com/v1/session"
     request(url: url, method: "DELETE", parameters: <#T##Data?#>, completion: <#T##(Bool, Data?) -> Void#>)
 */
    
    func logout(completion: @escaping (_ status: Bool) -> Void) {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { print(error)
                return
            }
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range) /* subset response data! */
            print(String(data: newData!, encoding: .utf8)!)
        }
        task.resume()
    }


    class func sharedInstance() -> UdacityAccountController {
        struct Singleton {
            static var sharedInstance = UdacityAccountController()
        }
        return Singleton.sharedInstance
    }
}

