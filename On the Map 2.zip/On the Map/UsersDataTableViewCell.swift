//
//  UsersDataTableViewCell.swift
//  On the Map
//
//  Created by Majed Sh on 2/13/19.
//  Copyright © 2019 Majed Sh. All rights reserved.
//

import Foundation
import UIKit

class UsersDataTableViewCell: UITableViewCell {
    
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var urlLabel: UILabel!
    @IBOutlet weak var icon: UIImageView!
    
    
    func fillCell(usersData: ParseNetworking.StudentLocation) {
        
        if let frist = usersData.firstName , let last = usersData.lastName , let url = usersData.mediaURL {
            
            fullNameLabel.text = "\(frist) \(last)"
            urlLabel.text = "\(url)"
            
        }
    }
    
    
    
}
